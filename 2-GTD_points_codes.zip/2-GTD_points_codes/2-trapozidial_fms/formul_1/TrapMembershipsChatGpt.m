function memberships = TrapMembershipsChatGpt(angle)
    % Verilen a�? (degree cinsinden) i�in 16 trapezoidal �yelik fonksiyonu hesaplar.
    % Her fonksiyonun merkezi: 0, 22.5, 45, ..., 337.5 derece.
    % �yelik 1 olan b�lge: �7.5� (toplam 15�); 7.5� ile 15� aras?: do?rusal ge�i?.
    %
    % Girdi:
    %   angle - 0 ile 360 aras?nda bir a�? (veya a�?lar?n vekt�r�)
    %
    % �?kt?:
    %   memberships - E?er angle bir skalerse 1x16 vekt�r,
    %                  e?er angle bir vekt�rse length(angle) x 16 matris,
    %                  her sat?r, 16 etiketin �yelik derecelerini i�erir.
    
    % 16 adet etiketin merkez a�?lar?
    centers = (0:15)' * 22.5;  % 16x1 vekt�r: 0, 22.5, 45, ..., 337.5
    
    % Sabitler (derece cinsinden)
    plateau_half = 7.5;   % �yeli?in 1 oldu?u b�lgenin yar?s?
    slope_width = 7.5;    % E?imli b�lgelerin geni?li?i (7.5� art??/azal??)
    full_width  = plateau_half + slope_width;  % 15� toplam, buradan 0'dan 15�'ye ge�i?
    
    % E?er angle vekt�r de?ilse vekt�re �evir
    if ~isvector(angle)
        error('Girdi angle bir skaler veya vekt�r olmal?.');
    end
    angle = angle(:);  % s�tun vekt�r yap
    
    N = length(angle);
    memberships = zeros(N, length(centers)); % sonu� matrisini �nceden ayarla
    
    % Her bir giri? a�? i�in, her bir trapezoidal fonksiyona olan �yelik derecesi hesapla
    for i = 1:N
        a = angle(i);
        for j = 1:length(centers)
            % A�?lar aras? fark? (dairesel fark: mod 360)
            diff = abs(a - centers(j));
            % Dairesel fark? al?n (360'dan b�y�k olanlar? d�zelt)
            diff = min(diff, 360 - diff);
            
            if diff <= plateau_half
                % Merkezde: �yelik 1
                memberships(i,j) = 1;
            elseif diff <= (plateau_half + slope_width)
                % Do?rusal d�?�?: (15 - diff) / 7.5
                memberships(i,j) = (plateau_half + slope_width - diff) / slope_width;
            else
                memberships(i,j) = 0;
            end
        end
    end
end

% �rnek kullan?m:
% Bir a�? de?eri i�in (�rne?in 10 derece) �yelik derecelerini hesaplayal?m.
% angle = 10;
% mu = TrapMembershipsChatGpt(angle);
% disp('�yelik dereceleri:');
% disp(mu);
