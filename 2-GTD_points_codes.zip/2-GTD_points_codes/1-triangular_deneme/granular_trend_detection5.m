function [ebs, TT, members_number2] = granular_trend_detection5(data, int, mm)
    %% Temel ayarlar ve ilk s?ralama
    [aa, bb] = size(data);
    % Veriyi, t�m sat?rlar ilk kolonun de?erine g�re k���kten b�y�?e s?ral?yoruz
    K = sortrows(data);
    
    % Zaman serisi numaralar?n? ekle (vekt�rize)
    onek = (1:aa)';  
    K = [onek, K];
    
    % ebsilon de?eri hesaplan?yor (t�m kolonlar �zerinden)
    maxx = max(max(K(:, 2:end)));
    minn = min(min(K(:, 2:end)));
    ebs = 3 * (maxx - minn) / aa;
    
    % K matrisinin boyutlar? (ilk s�tun indeks, geri kalan? veri)
    Kboyt = size(K);
    Ksutn = Kboyt(2) - 1;  % indeks s�tunu hari� s�tun say?s?
    
    % �nceden baz? de?i?kenleri olu?turuyoruz
    num_windows = Ksutn - int + 1;
    % all_G: kayan pencere her bir aral?k i�in gruplar?n tutuldu?u 3B matris
    all_G = zeros(aa, bb, num_windows);
    
    %% Kayan pencereyle gruplama i?lemi
    for h = 1:num_windows
        % h+1 ile h+int aras? s�tunlar; sondaki s�tun da orijinal s?ra numaras?
        KZ = [K(:, (h+1):(h+int)), K(:, 1)];  
        KK = sortrows(KZ);  % KK, ilk s�tuna g�re s?ral?
        
        % KK boyut bilgileri
        Kbyt = size(KK);
        Kstn = Kbyt(2) - 1;  % son s�tun s?ra numaras?, hesaplamaya kat?lm?yor
        
        %% ?lk grup atamas?: 
        % G matrisini, olas? maksimum grup say?s? ve �ye say?s? kadar (aa x aa) s?f?r matris olarak preallocate ediyoruz.
        G = zeros(aa, aa);
        G(1,1) = KK(1, int+1);  % ilk eleman, ilk grup
        alt = 2;  % sonraki grup i�in sat?r indeksi (grup numaras?)
        yan = 1;  % grup i�indeki eleman konumu
        for i = 1:(aa - 1)
            if (KK(i+1, 1) - KK(i, 1)) < ebs
                % Ayn? grup i�ine ekle (ilk seferde alt zaten 1 olmu? olacak)
                yan = yan + 1;
                G(alt-1, yan) = KK(i+1, int+1);
            else
                % Fark ebs'yi a??yorsa, yeni grup ba?lat
                alt = alt + 1;
                yan = 1;
                G(alt-1, yan) = KK(i+1, int+1);
            end
        end
        
        %% Grup i�i kontrol: 
        % Zaman ilerledik�e, grup i�erisindeki ard???k elemanlar aras?ndaki fark ebs'den b�y�kse,
        % grubu ikiye b�lmeye �al???yoruz.
        for q = 2:Kstn
            [satr, sutn] = size(G);
            for n = 1:aa
                % Mevcut sat?rdaki (gruptaki) eleman say?s?n? vekt�rel olarak hesapla
                count = sum(G(n,:) ~= 0);
                if count >= mm
                    for v = 1:(count - 1)
                        % Ge�ici olarak KK'yi yedekle
                        KR = KK;
                        % KK'n?n yeniden s?ralanabilmesi i�in d�zenlenmi? hali
                        KT = [KK(:, int+1), KK(:, 1:int)];
                        KK = sortrows(KT);
                        % q. s�tunda (zaman noktas?nda) ard???k elemanlar aras? fark
                        if abs(KK(G(n, v), q+1) - KK(G(n, v+1), q+1)) > ebs
                            % G'yi yeniden d�zenle: b�l�nme noktas?na g�re sat?rlar? kayd?r
                            GG = zeros(size(G));
                            if n > 1
                                GG(1:n-1, :) = G(1:n-1, :);
                            end
                            GG(n, 1:v) = G(n, 1:v);
                            if v < sutn
                                GG(n+1, 1:(sutn-v)) = G(n, (v+1):sutn);
                            end
                            if n < satr
                                GG(n+2:satr+1, :) = G(n+1:satr, :);
                            end
                            G = GG;
                            KK = KR;
                            break;
                        end
                        KK = KR;
                    end
                end
                % E?er n artarken G sat?r say?s? azalm??sa �?k
                if n >= size(G,1)
                    break;
                end
            end
        end
        
        % G matrisinin boyutunu al ve kayan pencere sonu�lar?na atama yap
        [roww, colll] = size(G);
        all_G(1:roww, 1:colll, h) = G;
    end
    
    %% Gruplar?n i?aretlenmesi: her zaman noktas?nda grup var m??
    all_GG = zeros(aa, bb+1, num_windows);
    for v = 2:(bb - int + 1)
        for f = 1:aa
            count_A = sum(all_G(f,:,v-1) ~= 0);
            count_B = sum(all_G(f,:,v) ~= 0);
            if count_A >= mm
                all_GG(f, :, v-1) = [1, all_G(f, 1:bb)];
            else
                all_GG(f, :, v-1) = [0, all_G(f, 1:bb)];
            end
            
            if count_B >= mm
                all_GG(f, :, v) = [1, all_G(f, 1:bb)];
            else
                all_GG(f, :, v) = [0, all_G(f, 1:bb)];
            end     
        end
    end
    
    %% Her gruptaki �ye say?s?n?n hesaplanmas?
    all_GG_members = zeros(aa, bb - int + 1);
    for t = 1:(bb - int + 1)
        for r = 1:aa
            count_C = sum(all_GG(r,:,t) ~= 0);
            if all_GG(r, 1, t) ~= 0
                all_GG_members(r, t) = count_C - 1;
            end
        end
    end
    
    %% Ayn? zaman noktas?nda tekrar eden gruplar?n tespiti ve noktasal d�zenlenmesi
    all_points = zeros(aa * int, aa, bb - int);
    ll = 0;  % all_points'te sat?r ekleme indeksi
    for i = 1:(bb - int)
        first = all_GG(:,:,i);
        second = all_GG(:,:,(i+1));
        for j = 1:aa 
            pr = 1;  % Benzer grup tespiti i�in bayrak
            if first(j,1) == 1   
                pr = pr - 1;
                ll = ll + 1;
                for k = 1:aa 
                    if second(k,1) == 1
                        if isequal(first(j,:), second(k,:))
                            pr = pr + 1;
                            all_points(ll, :, i) = first(j, 2:(aa+1));
                            ll = ll + 1;
                        end  
                    end
                end
            end
            if pr == 0
                add = 0;
                for x = 1:int
                    all_points(ll, :, i+add) = first(j, 2:(aa+1));
                    add = add + 1;
                end          
            end
        end
    end
    
    %% Birbirini i�eren farkl? gruplar?n tespiti ve d�zenlenmesi
    all_points_last = all_points;
    [raww, columnn, widthh] = size(all_points_last);
    for n = 1:widthh
        for m = 1:(raww - 1)
            first_row = all_points_last(m, :, n);
            if sum(first_row > 0) > 0
                for z = m+1:raww
                    second_row = all_points_last(z, :, n);
                    if sum(second_row > 0) > 0
                        xx = ismember(first_row, second_row);
                        yy = ismember(second_row, first_row);
                        xz = sum(xx == 0);
                        yz = sum(yy == 0);
                        if xz == 0
                            all_points_last(m, :, n) = zeros(1, columnn);
                            break;
                        elseif yz == 0
                            all_points_last(z, :, n) = zeros(1, columnn);
                            break;    
                        end
                    end
                end
            end
        end
    end
    
    %% Ortalama trend de?eri (TT) ve grup �ye say?s?n?n (members_number2) hesaplanmas?
    members_number1 = zeros(aa, widthh);
    members_number2 = zeros(aa, widthh);
    TT = zeros(aa, widthh);
    for i = 1:widthh
        zz = 0;
        for j = 1:raww
            mmbrs = sum(all_points_last(j,:,i) > 0);
            members_number1(j,i) = mmbrs;
            summ = 0;
            if mmbrs ~= 0
                zz = zz + 1;
                for k = 1:mmbrs
                    val = all_points_last(j,k,i);
                    summ = summ + K(val, i+1);
                end
                TT(zz, i) = summ / mmbrs;
                members_number2(zz, i) = mmbrs;
            end
        end
    end
    
    % TT�deki s?f?r de?erleri NaN ile de?i?tir
    [rw, col] = size(TT);
    for i = 1:rw
        for j = 1:col
            if TT(i, j) == 0
                TT(i, j) = NaN;
            end
        end
    end 
end
