function [ebs, TT, members_number2] = granular_trend_detection3(data, int, mm)
    % Veri boyutlar?n? belirle
    [aa, bb] = size(data);
    
    % Veriyi ilk s�tuna g�re artan s?rada d�zenle
    K = sortrows(data);    
    
    % Zaman serisi indekslerini olu?turup ilk s�tun olarak ekle (vekt�rize edildi)
    idx = (1:aa)';
    K = [idx, K];
    
    % �l��mler
    sa = aa;
    su = bb;
    
    % ebsilon de?eri hesaplama (data i�indeki t�m kolonlar �zerinden)
    maxx = max(max(K(:, 2:end)));
    minn = min(min(K(:, 2:end)));
    ebs = 3*(maxx - minn) / sa;
    
    % Parametreler
    Ksutn = size(K, 2) - 1; % K nin s�tun say?s? - indeks s�tunu
    num_windows = Ksutn - int + 1;
    
    % Grup sonu�lar?n? h�cre dizilerinde topluyoruz: bellek verimlili?i i�in
    all_G = cell(num_windows, 1);
    
    %% Kayan pencere i?lemi
    for h = 1:num_windows
        % Se�ilen aral?k i�in verilerin g�ncellenmi? alt k�mesi:
        % h+1 : h+int aras? kolonlar ve en son indeks s�tunu
        KZ = [K(:, (h+1):(h+int)), K(:, 1)];  
        % Kayan pencere verilerini s?ral?yoruz (ilk s�tuna g�re)
        KK = sortrows(KZ, 1);
        
        % ?lk gruplama: fark vekt�r�n� hesaplayarak gruplar aras? ayr?m? tespit et
        d = diff(KK(:, 1));
        % Fark ebs'den k���kse ayn? grup, b�y�kse yeni grup
        grp_idx = ones(size(KK, 1), 1);
        grp_idx(2:end) = 1 + cumsum(d >= ebs);
        
        % Her grubun �ye indekslerini h�cre dizisinde sakla (son s�tun, orijinal s?ra numaras?)
        num_groups = max(grp_idx);
        groups = cell(num_groups, 1);
        for g = 1:num_groups
            groups{g} = KK(grp_idx == g, end);
        end
        
        % ?leri zamanlardaki grup durumunu kontrol etmek ve g�ncellemek i�in
        % orijinal kodda i� i�e d�ng�ler bulunuyor. Bu k?s?m, bellek k?s?tlamas?n?
        % azaltmak amac?yla sadece gerekli hesaplamalar? yapacak ?ekilde yeniden d�zenlendi.
        for q = 2:(size(KK,2)-1)
            for g = 1:num_groups
                if numel(groups{g}) >= mm
                    grpVals = groups{g};
                    diffs = abs(diff(K(grpVals, h+q)));
                    if any(diffs > ebs)
                        split_idx = find(diffs > ebs);
                        newGroups = mat2cell(grpVals, diff([0; split_idx; numel(grpVals)]));
                        groups{g} = newGroups{1};
                        if numel(newGroups) > 1
                            groups = [groups(1:g); newGroups(2:end); groups(g+1:end)];
                            num_groups = numel(groups);
                        end
                    end
                end
            end
        end
        
        all_G{h} = groups;
    end
    
    %% Sonu�lar?n hesaplanmas?: Ortalama trend de?eri (TT) ve grup �ye say?s? (members_number2)
    TT_cell = cell(num_windows, 1);
    members_cell = cell(num_windows, 1);
    for w = 1:num_windows
        groups = all_G{w};
        nGroups = numel(groups);
        TT_window = NaN(nGroups, 1);
        members_window = zeros(nGroups, 1);
        for g = 1:nGroups
            grp = groups{g};
            nMembers = numel(grp);
            members_window(g) = nMembers;
            if nMembers >= mm
                TT_window(g) = mean( K(grp, w+1) );
            end
        end
        TT_cell{w} = TT_window;
        members_cell{w} = members_window;
    end
    
    % H�cre dizilerini matris haline getiriyoruz: her s�tun kayan pencere
    maxGroups = max(cellfun(@numel, TT_cell));
    TT = NaN(maxGroups, num_windows);
    members_number2 = zeros(maxGroups, num_windows);
    for w = 1:num_windows
        nGrp = numel(TT_cell{w});
        TT(1:nGrp, w) = TT_cell{w};
        members_number2(1:nGrp, w) = members_cell{w};
    end

    % NaN atamalar? (TT'deki s?f?rlar? NaN'a �evirmek)
    TT(TT == 0) = NaN;
    
end
