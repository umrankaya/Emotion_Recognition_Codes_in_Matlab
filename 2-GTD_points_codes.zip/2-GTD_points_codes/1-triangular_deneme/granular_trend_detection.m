function [ebs,TT,members_number2]=granular_trend_detection(data,int,mm)

[aa,bb]=size(data);
Z=data;

%%%%  MULTI-GRANULAR TREND DETECTION   %%%%%
K=sortrows(Z); % ilk kolonun de?erlerine g�re t�m sat?rlar? k���kten b�y�?e s?ral?yor.
 
% K nin ilk s�tununa zaman serilerinin numaralari eklenecek
sayi=0;
onek=[];
for ff=1:aa
    sayi=sayi+1;
    onek(ff,1)=sayi;
end

s=size(K); % (sat?r, s�tun)=(Y,X)
sa=s(1,1); % Y nin say?s?
su=s(1,2);  % X in say?s?

% % % % % % % % for j=1:sa
% % % % % % % % %     plot(K(j,:),'-b','linewidth',0.01)
% % % % % % % %     set(0, 'DefaultAxesColorOrder', [0 0 0;1 0 0; 0 0 1]);    
% % % % % % % %     plot(K(j,:),'linewidth',0.01)
% % % % % % % %     hold on    
% % % % % % % % end
% % % % % % % % xlabel("X")
% % % % % % % % ylabel("Z")
% % % % % % % % title('X ve Z koordinatlarina iz d�s�m�')
% % % % % % % % grid on


%%%  ebsilon degeri hesaplama  %%%
maxx=max(max(K));
minn=min(min(K));
ebs=3*(maxx-minn)/((sa)); %% (maxx-minn)/(sa)

K=[onek,K];
Kboyt=size(K);
Ksatr=Kboyt(1,1)-1;
Ksutn=Kboyt(1,2)-1;

trends=NaN(1,bb); % t�m trendlerin noktalar?n?n oldu?u matris
tr=0;
% h, kayan pencerenin aral?k miktar?nca birer birer ilerledi?i parametredir. 
all_G=zeros(aa,bb); % kayan penceredeki her aral?k i�in gruplar? toplar

for h=1:(Ksutn-int+1)
KK=[];
KZ=[];
KZ=[K(:,(h+1):(h+int)),K(:,1)]; %% aralik miktarina g�re kaydira kaydira K yi g�ncelleyip, her aralik i�in trend tesbit ediyoruz
KK=sortrows(KZ);
Kbyt=size(KK);
Kstr=Kbyt(1,1);
Kstn=Kbyt(1,2)-1; % KK nin son s�tunu seri numaras?, ondan dolay? �?kartt?k

%%% Ilk nokta Gruplandirma  %%%
G=[];
G(1,1)=KK(1,(int+1));
alt=2; %altgruba ge�mek i�in eklendi
yan=1; %grupta yer a�mak icin
for i=1:(sa-1)
    if (KK(i+1,1)-KK(i,1))<ebs
        if i==1
            alt=1;
            yan=yan+1;
            G(alt,yan)=KK(i+1,(int+1));
        else
            yan=yan+1;
            G(alt,yan)=KK(i+1,(int+1));
        end
       
    else
        if i==1
           alt=1;
           yan=1;
           alt=alt+1;
           G(alt,yan)=KK(i+1,(int+1));
           yan=1;
        else
           yan=1;
           alt=alt+1;
           G(alt,yan)=KK(i+1,(int+1));
           yan=1;
        end
    end
   
end % ilk gruplandirma


%G %baslangic noktasindaki gruplar
GG=[];
for q=2:(Kstn) % t�m zaman serisi i�in bak?l?yor
 byt=size(G);
 satr=byt(1,1);
 sutn=byt(1,2);
 
   %%%%  t�m zaman i�eriisnde gruplarin durumunu uzakliga g�re kontrol ediyor. %%%%%%
    for n=1:aa % G deki t�m gruplar (satirlar) i�in
      count=0;
      for o=1:sutn % her grubun (satirin) i�erisinee bak, ka� eleman oldugunu tespit et
        if G(n,o)~=0
          count=count+1;
        end
      end
      
      if count>=mm % gruptaki eleman sayisi en mm'ye esit veya b�y�kse
        for v=1:(count-1)
              GG=[];
              byt=size(G);
              satr=byt(1,1);
              sutn=byt(1,2);
              frst=G(n,v);
              last=G(n,(v+1));
              KR=[]; % KK nin orjinal halini kaydet
              KR=KK;
              KT=[]; % KK n?n de?erini kar??la?t?rmak i�in d�zenlendi
              KT=[KK(:,int+1),KK(:,1:int)];
              KK=sortrows(KT);
              if abs(KK(last,(q+1))-KK(frst,(q+1))) > ebs %% q. zamanda gruptaki ardisik elemanlarin arasindaki uzaklik
                  GG(1:(n-1),:)=G(1:(n-1),:);
                  GG(n,1:v)=G(n,1:v);
                  GG(n+1,1:(sutn-v))=G(n,(v+1):sutn);
                  GG(n+2:(satr+1),:)=G(n+1:satr,:);
                  G=GG;
                  KK=KR;
                  break;
              end
              KK=KR;
          end 
      end  
      byt=size(G);
      satr=byt(1,1);
      
      if n>=satr
          break;
      end
    end 
end

[roww,colll]=size(G);
all_G(1:roww,1:colll,h)=G;
end

all_GG=zeros(aa,(bb+1),(Ksutn-int+1)); % matrisi grup varmi diye denetleyerek 1,0 ile yeni kolon ekliyoruz
for v=2:(bb-int+1) %buras? all_G matrisinde gruplar? tesbit eder
    for f=1:aa % Her sat?r i�in grup olup/olmad???n? denetliyor.
        count_A=0;
        count_B=0;
        for g=1:aa
            if all_G(f,g,(v-1))~=0
                count_A=count_A+1;   
            end
            
            if all_G(f,g,v)~=0
                count_B=count_B+1;   
            end
        end
         
        % E?er grup varsa 1, de?ilse 0 ata
        if count_A >=mm
            all_GG(f,:,(v-1))=[1,all_G(f,:,(v-1))];
        else
            all_GG(f,:,(v-1))=[0,all_G(f,:,(v-1))];
        end
        
        if count_B >=mm
            all_GG(f,:,v)=[1,all_G(f,:,v)];
        else
            all_GG(f,:,v)=[0,all_G(f,:,v)];
        end     
    end
end

% Burasi, her grupta toplam ka� eleman varsa onu hesaplar
all_GG_members=zeros(aa,(bb-int+1));
for t=1:(bb-int+1) 
    for r=1:aa
        count_C=0;
        for k=1:(aa+1)
            if all_GG(r,k,t)~=0
                count_C=count_C+1;   
            end
        end
        
        if all_GG(r,1,t)~=0
            all_GG_members(r,t)=count_C-1;
        end
        
    end
    
end

first=[];
second=[];
all_points=[];

%**** Bu k?s?m, ayn? zaman noktas?nda ayn? grup tekrar etmi?se tesbit eder ve int aral???nda kaydedilen gruplar? noktasal olarak d�zenler.
ll=0; % all points matrisinde i. an?ndaki sat?r? bulmak i�in kullan?ld?
for i=1:(bb-int)
    first=all_GG(:,:,i);
    second=all_GG(:,:,(i+1));
    for j=1:aa 
        add=0;
        pr=1; % e?er i an?nda grupla, i+1 andaki second matrisinde herhangi bir grupla ayn? de?ilse, onu tespit eder.       
        if first(j,1)==1   
            pr=pr-1;
            ll=ll+1;
            for k=1:aa 
                if second(k,1)==1
                    eq=isequal(first(j,:),second(k,:));
%                     members=ismember(first(j,:),second(k,:));
%                     idx=any(members==0,2); % e?er gruplar birbirini kaps?yor ise members matrisi tamamen 1 olmas? laz?m. 0 varsa kapsanmayan yer var demektir
                    if eq==1 % gruplar?n e?itli?ine bak?yor
                        pr=pr+1;
                        tt=all_GG_members(j,i);
                        all_points(ll,:,i)=first(j,2:(aa+1));
                        ll=ll+1;
                    end  
                end
            end
        end
        if pr==0 % e?er grubun benzeri sonraki anda yoksa, int miktar? kadar pointleri yaz.
            add=0;
            for x=1:int
               all_points(ll,:,(i+add))=first(j,2:(aa+1));
               add=add+1;
            end          
        end
    end
end

%**** Bu k?s?m, ayn? zaman noktas?nda birbirini i�eren iki farkl? grubu tesbit eder ve int aral???nda kaydedilen gruplar? noktasal olarak d�zenler.
all_points_last=all_points;
[raww,columnn,widthh]=size(all_points_last);

for n=1:widthh
    for m=1:(raww-1)
        first=all_points_last(m,:,n);
        first_n=sum(any(first(1,:)>0,1));
        if first_n>0
            for z=2:raww
                if m~=z
                    second=all_points_last(z,:,n);
                    second_n=sum(any(second(1,:)>0,1));
                    if second_n>0
                        xx=ismember(first,second);
                        yy=ismember(second,first);
                        xz=sum(any(xx(1,:)==0,1));
                        yz=sum(any(yy(1,:)==0,1));
                        
                        if xz==0 % ismember, 1. grubun tamamen 2. grubun i�inde oldu?unu yy=0 olmakla g�steriyor
                           all_points_last(m,:,n)=zeros(1,columnn);
                           break;
                           
                        elseif yz==0 % ismember, 2. grubun tamamen 1. grubun i�inde oldu?unu yy=0 olmakla g�steriyor
                           all_points_last(z,:,n)=zeros(1,columnn);
                           break;    
                           
                        end
                    end
                end
            end
        end
    end
end

members_number1=[]; %T�m noktalar?n matrisini g�sterir
members_number2=[]; % Sadece grupla?ma oldu?u grup say?s?n? noktasal g�sterir
TT=[];
values=0;
for i=1:widthh
    zz=0;
    for j=1:raww
        mmbrs=sum(any(all_points_last(j,:,i)>0,1));
        members_number1(j,i)=mmbrs;
        summ=0;
        avrg=0;
        if mmbrs~=0
            zz=zz+1;
            for k=1:mmbrs
                values=all_points_last(j,k,i);
                summ=summ + K(values,(i+1));        
            end
            avrg=summ/mmbrs;
            TT(zz,i)=avrg;
            members_number2(zz,i)=mmbrs;
        end
    end
end

sz=size(TT);
rw=sz(1,1);
col=sz(1,2);

for i=1:rw
    for j=1:col
        if TT(i,j)==0
             TT(i,j)=NaN;     
        end
    end
end 

% % % % % % % % for i=1:col
% % % % % % % %     for j=1:rw  
% % % % % % % %         if members_number2(j,i)~=0
% % % % % % % %         
% % % % % % % %             count=members_number2(j,i);   
% % % % % % % %             plot([i,i+ 0.999],[TT(j,i),TT(j,i)],'-r','linewidth',2, "LineStyle",'--');
% % % % % % % %             hold on
% % % % % % % %             plot([i,i+ 0.999],[TT(j,i),TT(j,i)],'-r','linewidth',(count*count),"color",[0.4,0.4,0.4,0.5]);
% % % % % % % %             hold on
% % % % % % % %             
% % % % % % % %         else
% % % % % % % %             plot([i,i+ 0.1],[TT(j,i),TT(j,i)],'-r','linewidth',2, "LineStyle",'--');
% % % % % % % %             hold on
% % % % % % % %             plot([i,i+ 0.1],[TT(j,i),TT(j,i)],'-r','linewidth',(2.5),"color",[0.4,0.4,0.4,0.5]);
% % % % % % % %             hold on
% % % % % % % %         end
% % % % % % % %     end
% % % % % % % % end


% % % TT
% % % members_number2
% % % ebs 

end

