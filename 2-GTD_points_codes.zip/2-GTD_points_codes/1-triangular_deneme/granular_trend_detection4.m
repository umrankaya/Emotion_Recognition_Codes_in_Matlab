function [ebs, TT, members_number2] = granular_trend_detection4(data, int, mm)
    %%% Temel ayarlar
    [aa, bb] = size(data);
    Z = data;
    
    %%% MULTI-GRANULAR TREND DETECTION
    % Veriyi ilk s�tuna g�re artan s?rada d�zenle
    K = sortrows(Z);
    
    % Zaman serisi numaralar?n? vekt�rize ekle
    onek = (1:aa)';  
    K = [onek, K];
    
    % Boyut bilgileri
    sa = aa;
    su = bb;
    
    % ebsilon de?eri hesaplama (data i�indeki t�m de?erler �zerinden)
    maxx = max(max(K(:, 2:end)));
    minn = min(min(K(:, 2:end)));
    ebs = 3*(maxx - minn) / sa;
    
    % K matrisinin g�ncel boyutlar?
    Kboyt = size(K);
    Ksatr = Kboyt(1) - 1;
    Ksutn = Kboyt(2) - 1;
    
    trends = NaN(1, bb); % (kullan?lan ancak sonradan i?lenen trendler i�in)
    tr = 0;
    
    % �ncelikle, kayan pencere sonu�lar?n? dinamik olarak saklamak i�in 3D matris
    % (boyutlar: [aa x bb x num_windows]) kullan?lm??t?r.
    num_windows = Ksutn - int + 1;
    all_G = zeros(aa, bb, num_windows);
    
    %% Kayan pencere �zerinden gruplama i?lemi
    for h = 1:num_windows
        % h+1 : h+int aras? s�tunlar ve en son indis s�tunu ekleniyor
        KZ = [K(:, (h+1):(h+int)), K(:, 1)];  
        KK = sortrows(KZ);  % ?lk s�tuna g�re s?ralama
        
        % KK matrisinin boyut bilgileri
        Kbyt = size(KK);
        Kstr = Kbyt(1);
        Kstn = Kbyt(2) - 1;  % Son s�tun, seri numaras? oldu?u i�in �?kart?ld?
        
        %%% ?lk nokta gruplamas?
        % G'yi, maksimum grup ve �yeler i�in yeterli boyutta (aa x aa) s?f?r matrisi olarak tan?ml?yoruz.
        G = zeros(aa, aa);
        G(1,1) = KK(1, int+1);  % ?lk grup ilk eleman?
        alt = 2;  % Yeni grup i�in sat?r indeksi
        yan = 1;  % Grup i�indeki eleman konumu
        
        for i = 1:(sa - 1)
            if (KK(i+1, 1) - KK(i, 1)) < ebs
                % Ayn? grup i�erisinde; ayn? sat?r?n devam?
                yan = yan + 1;
                G(alt-1, yan) = KK(i+1, int+1);
            else
                % Yeni grup ba?l?yor
                alt = alt + 1;
                yan = 1;
                G(alt-1, yan) = KK(i+1, int+1);
            end
        end
        
        %%% Grup i�i d�zenleme: Zaman serisi ilerleyi?ine g�re gruplar?n durumunu kontrol et
        GG = [];
        for q = 2:Kstn   % q. zaman diliminde
            [satr, sutn] = size(G);
            for n = 1:aa
                count = 0;
                % Bir sat?rdaki (gruptaki) eleman say?s?n? hesapla
                for o = 1:sutn
                    if G(n, o) ~= 0
                        count = count + 1;
                    end
                end
                if count >= mm  % Grup yeterince elemanl? ise
                    for v = 1:(count - 1)
                        GG = [];  % Ge�ici grup
                        [satr, sutn] = size(G);
                        frst = G(n, v);
                        last = G(n, v+1);
                        KR = KK; % KK'nin orijinal halini sakla
                        KT = [KK(:, int+1), KK(:, 1:int)];
                        KK = sortrows(KT);
                        % q. zamanda ard???k elemanlar aras? fark ebs'ten b�y�kse, grubu b�l
                        if abs(KK(last, q+1) - KK(frst, q+1)) > ebs
                            GG(1:(n-1), :) = G(1:(n-1), :);
                            GG(n, 1:v) = G(n, 1:v);
                            GG(n+1, 1:(sutn-v)) = G(n, (v+1):sutn);
                            GG(n+2:(satr+1), :) = G(n+1:satr, :);
                            G = GG;
                            KK = KR;
                            break;
                        end
                        KK = KR;
                    end
                end
                [satr, ~] = size(G);
                if n >= satr
                    break;
                end
            end
        end
        
        % Kaydedilen grubu, kayan pencereye ait sonu� olarak yerle?tiriyoruz
        [roww, colll] = size(G);
        all_G(1:roww, 1:colll, h) = G;
    end
    
    %% Gruplar?n i?aretlenmesi: her zaman noktas?nda grup var m??
    all_GG = zeros(aa, bb+1, num_windows);
    for v = 2:(bb - int + 1)
        for f = 1:aa
            count_A = 0;
            count_B = 0;
            for g = 1:aa
                if all_G(f, g, v-1) ~= 0
                    count_A = count_A + 1;   
                end
                if all_G(f, g, v) ~= 0
                    count_B = count_B + 1;   
                end
            end
            if count_A >= mm
                all_GG(f, :, v-1) = [1, all_G(f, :, v-1)];
            else
                all_GG(f, :, v-1) = [0, all_G(f, :, v-1)];
            end
            if count_B >= mm
                all_GG(f, :, v) = [1, all_G(f, :, v)];
            else
                all_GG(f, :, v) = [0, all_G(f, :, v)];
            end     
        end
    end
    
    %% Her gruptaki �ye say?s?n?n hesaplanmas?
    all_GG_members = zeros(aa, bb - int + 1);
    for t = 1:(bb - int + 1)
        for r = 1:aa
            count_C = 0;
            for k = 1:(aa + 1)
                if all_GG(r, k, t) ~= 0
                    count_C = count_C + 1;   
                end
            end
            if all_GG(r, 1, t) ~= 0
                all_GG_members(r, t) = count_C - 1;
            end
        end
    end
    
    %% Ayn? zaman noktas?nda tekrar eden gruplar?n tespiti ve noktasal d�zenlenmesi
    all_points = zeros(aa * int, aa, bb - int);
    ll = 0; % all_points matrisinde sat?r eklemek i�in
    for i = 1:(bb - int)
        first = all_GG(:, :, i);
        second = all_GG(:, :, i+1);
        for j = 1:aa
            pr = 1;  % Varsay?lan: benzer grup yok
            if first(j, 1) == 1   
                pr = pr - 1;
                ll = ll + 1;
                for k = 1:aa 
                    if second(k, 1) == 1
                        if isequal(first(j, :), second(k, :))
                            pr = pr + 1;
                            % tt = all_GG_members(j,i);  (hesaplamaya dahil, ancak �?kt? olarak kullan?lm?yor)
                            all_points(ll, :, i) = first(j, 2:(aa+1));
                            ll = ll + 1;
                        end  
                    end
                end
            end
            if pr == 0  % Benzeri yoksa, int kadar ayn? noktay? yaz
                add = 0;
                for x = 1:int
                    all_points(ll, :, i + add) = first(j, 2:(aa+1));
                    add = add + 1;
                end          
            end
        end
    end
    
    %% Birbirini i�eren farkl? gruplar?n tespiti ve d�zenlenmesi
    all_points_last = all_points;
    [raww, columnn, widthh] = size(all_points_last);
    for n = 1:widthh
        for m = 1:(raww - 1)
            first_row = all_points_last(m, :, n);
            first_n = sum(first_row > 0);
            if first_n > 0
                for z = 2:raww
                    if m ~= z
                        second_row = all_points_last(z, :, n);
                        second_n = sum(second_row > 0);
                        if second_n > 0
                            xx = ismember(first_row, second_row);
                            yy = ismember(second_row, first_row);
                            xz = sum(xx == 0);
                            yz = sum(yy == 0);
                            if xz == 0  % first tamamen second�?n i�inde
                                all_points_last(m, :, n) = zeros(1, columnn);
                                break;
                            elseif yz == 0  % second tamamen first�?n i�inde
                                all_points_last(z, :, n) = zeros(1, columnn);
                                break;    
                            end
                        end
                    end
                end
            end
        end
    end
    
    %% Ortalama trend de?eri (TT) ve grup �ye say?s? (members_number2) hesaplan?yor
    members_number1 = zeros(aa, widthh);
    members_number2 = zeros(aa, widthh);
    TT = zeros(aa, widthh);
    for i = 1:widthh
        zz = 0;
        for j = 1:raww
            mmbrs = sum(all_points_last(j, :, i) > 0);
            members_number1(j, i) = mmbrs;
            summ = 0;
            if mmbrs ~= 0
                zz = zz + 1;
                for k = 1:mmbrs
                    val = all_points_last(j, k, i);
                    summ = summ + K(val, i+1);
                end
                TT(zz, i) = summ / mmbrs;
                members_number2(zz, i) = mmbrs;
            end
        end
    end
    
    % TT�deki s?f?r de?erleri NaN ile de?i?tir
    [rw, col] = size(TT);
    for i = 1:rw
        for j = 1:col
            if TT(i, j) == 0
                TT(i, j) = NaN;
            end
        end
    end
end
