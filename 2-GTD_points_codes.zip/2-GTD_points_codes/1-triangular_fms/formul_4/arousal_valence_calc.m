function [arousal,valence]=arousal_valence_calc(EEG_data)

[num_of_points,coloumn]=size(EEG_data); % Calculated the size of EEG signal points
iteration_size=coloumn/4; % should be 17

%This function is created to calculate the arousal and valence values from frontol alpha and betha signals. 
%Reference: Ramirez, R., et al., Musical neurofeedback for treating depression in elderly people. METHOD, 2015: p. 1-10.

arousal=[];
valence=[];
for i=1:iteration_size
    
    %Extracting features
    a_AF7=EEG_data(:,(4*i-3));
    a_AF8=EEG_data(:,(4*i-2));
    b_AF7=EEG_data(:,(4*i-1));
    b_AF8=EEG_data(:,(4*i));
    
    ar=((b_AF7)+(b_AF8))./((a_AF7)+(a_AF8)); %formula
    val=(a_AF8)-(a_AF7); %formula
    % Creating Arousal and Valence data
    arousal(:,i)=ar(:,:);
    valence(:,i)=val(:,:);

end
