clc;
clear all;

%%%%%%%%%%%%%%%%%--------------------------------------------------%%%%%%%%%%%%%%%%%%%%%%%%%
                            %%% Getting DATA from source file %%%
%%%%%%%%%%%%%%%%%--------------------------------------------------%%%%%%%%%%%%%%%%%%%%%%%%%

main_folder = 'D:\Users\umran.kaya\Desktop\SEED_EEG\Preprocessed_EEG\Preprocessed_EEG\1-Veriler\last_version'; % Ana klas�r yolu
subfolders = dir(main_folder);
subfolders = subfolders([subfolders.isdir] & ~ismember({subfolders.name}, {'.', '..'})); % Ge�erli alt klas�rleri se�

file_names = {'dataa_audio', 'dataa_video', 'dataa_web'}; % Sabit dosya isimleri
combined_video_based_all=[];
combined_subject_based_all=[];

for i = 1:length(subfolders)
    subfolder_path = fullfile(main_folder, subfolders(i).name); % Alt klas�r�n tam yolu
    mat_files = dir(fullfile(subfolder_path, '*.mat')); % .mat dosyalar?n? listele
    
    for j = 1:min(length(mat_files), 3) % ?lk 3 dosya i�in i?lem yap
        mat_file_path = fullfile(subfolder_path, mat_files(j).name); % .mat dosyas?n?n tam yolu
        var_name = file_names{j}; % Sabit isimleri kullan
        eval([var_name ' = load(mat_file_path);']); % .mat dosyas?n? y�kleyip de?i?kene ata
%         fprintf('Y�klendi: %s\%s\%s ve de?i?kene atand?: %s\n', main_folder, subfolders(i).name, mat_files(j).name, var_name);
    end

% veri matrix hale d�n�?t�r�l�yor
dataa_audio=struct2cell(dataa_audio);
EEG_audio=cell2mat(dataa_audio(1,1));


% && Calculating Arousal and Valence values and Resulting with converting them with normalization method &&%
                                        %%% for AUDIO EEG DATA %%%%
[arousal_audio,valence_audio]=arousal_valence_calc(EEG_audio); % a function that calculating the arousal and valence values
arousal_audio=real(arousal_audio);
valence_audio=real(valence_audio);
                                      
           %&& Calculating TETHA (Q) angle that shows the emotion in Russel's circle &&%
 %%% for AUDIO EEG DATA %%%%
 [all_angles_audio]=all_angles_calc(arousal_audio,valence_audio);
 
%%%%%%%%%%%%------------------- Creating Granular Trend Detection -----------------%%%%%%%%%%%%%%%%%
 interval=3;
 number_of_member=3;
                             %%%%%%%--- for Russel Circle ---%%%%%%%%
 [ebs,group_points_audio,group_density_audio]=granular_trend_detection(all_angles_audio,interval,number_of_member);
 
                     %&---------------- EMOTIONS FUZZY SETS---------------- %&
%& 1) ALL EMOTIONS LABELS:

labels_all_emotion={'happy','elated','excited','alert','tense','nervous','stressed','upset','sad','depressed','lethargic','fatigued','calm','relaxed','serene','contented'}; % labels used in emotion detection. This data used in label_fuzzy_set

% These "all_emotions_mmbrship_dgre_audio/video/web" matrix size is 300*16*17. 
% It means that for all 17 people, 300 time points' value is converted to 16 emotions' membership degree.
 
[all_emotions_mmbrship_dgre_audio_zz]=mem_degree_for_all_emotion(group_points_audio,labels_all_emotion);

zz_audio=(all_emotions_mmbrship_dgre_audio_zz)/max(max(group_density_audio)); % get the max density number and divie with it

[tki,tka,tku]=size(zz_audio);
all_emotions_mmbrship_dgre_audio=zeros(tki,tka,tku);
for mr=1:tku
    all_emotions_mmbrship_dgre_audio(:,:,mr)=zz_audio(:,:,mr).*group_density_audio(:,mr); % multiple cell ith its own density
end

% T�m emotionlar i�in �yelik derecelerinin toplam? hesaplan?yor
video_based_all_emotion_1_trial=[];

subject_based_all_emotion_1_trial=[];

[raww_1,~,depth_1]=size(all_emotions_mmbrship_dgre_audio);

for hh=1:16 % 16 adet duygu oldu?u i�in
    % video bazl? �yelik dreceleri toplan?yor
    video_based_all_emotion_1_trial(1,hh) = (sum(sum(all_emotions_mmbrship_dgre_audio(:,hh,:)))/(raww_1*depth_1));
    
    for pp=1:15 % 15 ki?i oldu?u i�in
        subject_based_all_emotion_1_trial(pp,hh) = (sum(all_emotions_mmbrship_dgre_audio(:,hh,pp))/(raww_1)); % sat?rda ki?iler, s�tunda duygu �yelikleri
    end    
end

video_based_all=[video_based_all_emotion_1_trial];
p3=[subject_based_all_emotion_1_trial];
subject_based_all=[p3];

combined_video_based_all(i,:)=video_based_all;
combined_subject_based_all(:,:,i)=subject_based_all;

end

% Ki?i bazl? verileri d�zenlemek i�in...
[raww,coloumn,depth]=size(combined_subject_based_all);
subject_based_redesign=[];
for tt=1:depth % videolara g�re..
    for mm=1:15 % ki?ilere g�re..
        subject_based_redesign((3*tt-2),:,mm)=combined_subject_based_all(mm,:,tt); % ki?inin 1. trial?
%         subject_based_redesign((3*tt-1),:,mm)=combined_subject_based_all((mm+15),:,tt); % ki?inin 2. trial?
%         subject_based_redesign((3*tt),:,mm)=combined_subject_based_all((mm+30),:,tt); % ki?inin 3. trial?
    end
end

% assignment of points
PopulationSize=50000;
mmbrships=combined_video_based_all(:,1:16);
[columnsPoz, columnsNotr, columnsNeg, Overall_Accuracy] = EmotionGroups(mmbrships, PopulationSize);

%%%%%%%%%%%%%% Accuracy calculation for overall video  %%%%%%%%%%%%%%

% Ger�ek etiketler 1=pozitive, 2=neurtal, 3=negative
trueLabels = [1, 2, 3, 3, 2, 1, 3, 2, 1, 1, 2, 3, 2, 1, 3];
actualLabels=[];
pnn=[]; % pozitif, n�tr ve negatif de?erleri tutacak

for la=1:15 % her video i�in pozitif, n�tr ve negatif de?erler hesaplanacak
    pnn(1,1)=sum(mmbrships(la, columnsPoz));
    pnn(1,2)=sum(mmbrships(la, columnsNotr));
    pnn(1,3)=sum(mmbrships(la, columnsNeg));
    
    [max_val, linear_idx] = max(pnn(:)); % hangi etiketse indexini belirler
    actualLabels(1,la)=linear_idx;   
end

% Dogru tahminlerin oran? (dogruluk)
dogruluk = sum(trueLabels == actualLabels) / numel(trueLabels);
% Sonucu y�zde olarak g�sterme
disp(['Accuracy: ', num2str(dogruluk * 100), '%']);



%%%%%%%%%%%%%% Accuracy calculation for subject based  %%%%%%%%%%%%%%
% Ger�ek etiketler 1=pozitive, 2=neurtal, 3=negative
% trueLabels = [1, 2, 3, 3, 2, 1, 3, 2, 1, 1, 2, 3, 2, 1, 3];

mmbrships_subject=subject_based_redesign(1:15,:,:);
pnn_s=[]; % pozitif, n�tr ve negatif de?erleri tutacak
accuracy_subject_based=zeros(1,15);

for la_i=1:15 % her ki?i i�in pozitif, n�tr ve negatif degerler hesaplanacak
    actualLabelsSubject=zeros(1,15);
    for la_il=1:15 % bireysel bazda t�m videolara bakacak
        
        pnn_s(1,1)=sum(mmbrships_subject(la_il, columnsPoz,la_i));
        pnn_s(1,2)=sum(mmbrships_subject(la_il, columnsNotr,la_i));
        pnn_s(1,3)=sum(mmbrships_subject(la_il, columnsNeg,la_i));

        [max_val, linear_idx] = max(pnn_s(:)); % hangi etiketse indexini belirler
        actualLabelsSubject(1,la_il)=linear_idx;   
    end
    % Dogru tahminlerin oran? (dogruluk)
    dogruluk_subject = sum(trueLabels == actualLabelsSubject) / numel(trueLabels);
    accuracy_subject_based(1,la_i)=dogruluk_subject;
end


% Dosyaya yazma
% Sonu�lar
% Dosya konumu ve ismi
outputFolder = 'D:\Users\umran.kaya\Desktop\SEED_EEG\Preprocessed_EEG\Preprocessed_EEG\3-Sonuclar\2-granular_results';
fileName = 'output33.txt';

% Dosyay? a� ve yaz
fileID = fopen(fullfile(outputFolder, fileName), 'w');

% Sonu�lar? alt alta ba?l?klarla yaz
fprintf(fileID, 'Overall Accuracy: %.2f\n', Overall_Accuracy);
fprintf(fileID, 'Dogruluk: %.2f\n', dogruluk);
fprintf(fileID, 'Accuracy Based on Subject:\n');
fprintf(fileID, '%.2f\n', accuracy_subject_based');
fprintf(fileID, 'columnsPoz =:\n');
fprintf(fileID, '%.0f\n', columnsPoz');
fprintf(fileID, 'columnsNotr =:\n');
fprintf(fileID, '%.0f\n', columnsNotr');
fprintf(fileID, 'columnsNeg =:\n');
fprintf(fileID, '%.0f\n', columnsNeg');

fclose(fileID);

disp('Sonu�lar belirtilen klas�re tek bir dosyada yaz?ld?!');
