function memberships = computeGaussianMemberships(angle)
    % Verilen a�? (degree cinsinden) i�in 16 adet Gaussian �yelik fonksiyonu hesaplar.
    % Her bir etiketin merkezi: 0, 22.5, 45, ..., 337.5 derece.
    % Gaussian �yelik fonksiyonu: mu = exp(-0.5 * ((diff)/sigma)^2)
    % Burada diff, merkeze olan dairesel fark (minimum fark olarak hesaplan?r).
    %
    % Girdi:
    %   angle - 0 ile 360 aras?nda bir a�? (veya a�?lar?n vekt�r�)
    %
    % �?kt?:
    %   memberships - E?er angle bir skaler ise 1x16 vekt�r,
    %                  e?er angle bir vekt�rse length(angle) x 16 matris,
    %                  her sat?r 16 etiketin �yelik derecelerini i�erir.
    
    % Etiket merkez a�?lar? (16 adet)
    centers = (0:15)' * 22.5;  % 16x1 vekt�r: 0, 22.5, 45, ..., 337.5
    
    % Gaussian parametreleri:
    FWHM = 15;  % Full Width at Half Maximum (15 derece)
    sigma = FWHM / (2*sqrt(2*log(2)));  % yakla??k 6.37 derece
    
    % Girdi a�?lar?n? s�tun vekt�re �evirme
    if ~isvector(angle)
        error('Girdi angle bir skaler veya vekt�r olmal?.');
    end
    angle = angle(:);  % s�tun vekt�r
    
    N = length(angle);
    memberships = zeros(N, length(centers)); % sonu� matrisi �nceden ayr?l?r
    
    % Her bir giri? a�?s? i�in, her bir Gaussian �yelik fonksiyonunu hesapla
    for i = 1:N
        a = angle(i);
        for j = 1:length(centers)
            % Dairesel fark hesaplan?r
            diff = abs(a - centers(j));
            diff = min(diff, 360 - diff);  % 360 derecelik dairesel fark
            
            % Gaussian �yelik de?eri
            memberships(i,j) = exp(-0.5 * (diff/sigma)^2);
        end
    end
end

% �rnek kullan?m:
% �rne?in, 10 derece i�in �yelik derecelerini hesaplayal?m.
% angle = 10;
% mu = computeGaussianMemberships(angle);
% disp('Gaussian �yelik dereceleri:');
% disp(mu);
