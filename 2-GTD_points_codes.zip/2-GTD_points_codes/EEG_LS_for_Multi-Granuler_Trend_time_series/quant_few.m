function [ y ] = quant_few( x )
%UNT�TLED4 Summary of this function goes here
%   Detailed explanation goes here

if x<=0.25
    y=x/0.25;
elseif x<=0.5
    y=(0.5-x)/0.25;
else
    y=0;
end
end

