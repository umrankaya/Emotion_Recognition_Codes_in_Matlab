function [GTD_P2_audio_sentences,GTD_P2_video_sentences,GTD_P2_web_sentences]=granular_TD_protoform_2(Quantifier,labels_all_emotion,all_emotions_mmbrship_dgre_audio,all_emotions_mmbrship_dgre_video,all_emotions_mmbrship_dgre_web,Y_ad,treshold,seg_number,allsize)

% This function create the sentences for all volunteers for each advertising. 
% Quantififers, labels, memebership degrees and treshold are input of this function.
% all sentences for each ad are output of this function

[fq,quant]=size(Quantifier);
[fl,summarizer]=size(labels_all_emotion);
[fy,ad_number]=size(Y_ad);
GTD_P2_audio_sentences=[];
GTD_P2_video_sentences=[];
GTD_P2_web_sentences=[];

for ad=1:ad_number % looking for ad number
    for q=1:quant  % looking for each used quantifier
        for s=1:summarizer % looking for each used emotion
            for seg=1:seg_number % looking for each segment
                if ad==1 % for Audio ad
                    [TD]=truth_degree_2(q,s,all_emotions_mmbrship_dgre_audio,seg_number,seg,allsize);
                    if TD>=treshold
                        % Creating summarization and Truth Degree of summary
                        sentence=[Quantifier(1,q),'time of','quarter_',seg,'of  ',Y_ad(1,ad),'ad',labels_all_emotion(1,s),'emotion are observed simultaneously as a group',num2str(TD)];
                        GTD_P2_audio_sentences=[GTD_P2_audio_sentences;sentence];
                    end
                elseif ad==2 % for Video ad
                    [TD]=truth_degree_2(q,s,all_emotions_mmbrship_dgre_video,seg_number,seg,allsize);
                    if TD>=treshold
                        % Creating summarization and Truth Degree of summary
                        sentence=[Quantifier(1,q),'time of','quarter_',seg,'of  ',Y_ad(1,ad),'ad',labels_all_emotion(1,s),'emotion are observed simultaneously as a group',num2str(TD)];
                        GTD_P2_video_sentences=[GTD_P2_video_sentences;sentence];
                    end
                else % for Web ad
                    [TD]=truth_degree_2(q,s,all_emotions_mmbrship_dgre_web,seg_number,seg,allsize);
                    if TD>=treshold
                        % Creating summarization and Truth Degree of summary
                        sentence=[Quantifier(1,q),'time of','quarter_',seg,'of  ',Y_ad(1,ad),'ad',labels_all_emotion(1,s),'emotion are observed simultaneously as a group',num2str(TD)];
                        GTD_P2_web_sentences=[GTD_P2_web_sentences;sentence];
                    end
                end
            end
        end
    end
end
end