function [TD]=truth_degree_5(AW_index_mmbrship_dgre_audio,AW_index_mmbrship_dgre_video,AW_index_mmbrship_dgre_web,ad1,ad2)

%This function calculate the truth degree which is based scaler cardinality
%for type-1. Names of this TD is Zadeh's truth degree

% 's' represents the used Summerizer (emotion label),  BUT IN THIS DESC. WE ALL USE 'POSITIVE' LABEL. SO FIXED S=3.
% 'AW_index_mmbrship_dgre_audio' represents calculated membership degree matrix,
% 'segment_part' represents which segment of data has been used.


%%% Calculatig the Ad1's TD
looking1=0;
tootally1=0;
vallue1=0;
td1=0;
if ad1==1  
    [points_size,emotion_size,all_time]=size(AW_index_mmbrship_dgre_audio);
    for pn=1:all_time
        for hn=1:points_size
            looking1=sum(any(AW_index_mmbrship_dgre_audio(hn,3,pn)>0,1));
            if looking1>0
                vallue1=vallue1+1;
                tootally1=tootally1+AW_index_mmbrship_dgre_audio(hn,3,pn);
            end
        end
    end 
    td1=tootally1/vallue1;
elseif ad1==2
    [points_size,emotion_size,all_time]=size(AW_index_mmbrship_dgre_video);
    for pn=1:all_time
        for hn=1:points_size
            looking1=sum(any(AW_index_mmbrship_dgre_video(hn,3,pn)>0,1));
            if looking1>0
                vallue1=vallue1+1;
                tootally1=tootally1+AW_index_mmbrship_dgre_video(hn,3,pn);
            end
        end
    end 
    td1=tootally1/vallue1; 
else
    [points_size,emotion_size,all_time]=size(AW_index_mmbrship_dgre_web);
    for pn=1:all_time
        for hn=1:points_size
            looking1=sum(any(AW_index_mmbrship_dgre_web(hn,3,pn)>0,1));
            if looking1>0
                vallue1=vallue1+1;
                tootally1=tootally1+AW_index_mmbrship_dgre_web(hn,3,pn);
            end
        end
    end 
    td1=tootally1/vallue1; 
end


%%% Calculatig the Ad2's TD
looking2=0;
tootally2=0;
vallue2=0;
td2=0;

if ad2==1  
    [points_size,emotion_size,all_time]=size(AW_index_mmbrship_dgre_audio);
    for pn=1:all_time
        for hn=1:points_size
            looking2=sum(any(AW_index_mmbrship_dgre_audio(hn,3,pn)>0,1));
            if looking2>0
                vallue2=vallue2+1;
                tootally2=tootally2+AW_index_mmbrship_dgre_audio(hn,3,pn);
            end
        end
    end 
    td2=tootally2/vallue2;
elseif ad2==2
    [points_size,emotion_size,all_time]=size(AW_index_mmbrship_dgre_video);
    for pn=1:all_time
        for hn=1:points_size
            looking2=sum(any(AW_index_mmbrship_dgre_video(hn,3,pn)>0,1));
            if looking2>0
                vallue2=vallue2+1;
                tootally2=tootally2+AW_index_mmbrship_dgre_video(hn,3,pn);
            end
        end
    end 
    td2=tootally2/vallue2; 
else
    [points_size,emotion_size,all_time]=size(AW_index_mmbrship_dgre_web);
    for pn=1:all_time
        for hn=1:points_size
            looking2=sum(any(AW_index_mmbrship_dgre_web(hn,3,pn)>0,1));
            if looking2>0
                vallue2=vallue2+1;
                tootally2=tootally2+AW_index_mmbrship_dgre_web(hn,3,pn);
            end
        end
    end 
    td2=tootally2/vallue2; 
end

td=max(0,(td1-td2));

% 'more' quantifier functions are defined before and used.

    [ TD ] = quant_more(td);
end