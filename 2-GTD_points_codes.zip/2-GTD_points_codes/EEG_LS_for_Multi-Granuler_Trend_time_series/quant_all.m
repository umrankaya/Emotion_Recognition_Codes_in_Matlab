function [ y ] = quant_all( x )
%UNT�TLED3 Summary of this function goes here
%   Detailed explanation goes here
% THIS CALCULATED ACCORDING TO PHD THESIS. HAKAN 
if x==1
    y=1;
else
    y=0;
end
end