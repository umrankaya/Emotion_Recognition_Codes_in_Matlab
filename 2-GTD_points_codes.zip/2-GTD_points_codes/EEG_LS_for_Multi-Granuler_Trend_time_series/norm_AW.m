function [AW_n]=norm_AW(AW)
% AW=AW';
[rw,clmn]=size(AW); % should be [300,17]

AW_n=[];

for j=1:clmn
    for i=1:rw
        AW_n(i,j)=2*(AW(i,j)-min(AW(:,j)))/(max(AW(:,j))-min(AW(:,j)))-1;
    end
end

end