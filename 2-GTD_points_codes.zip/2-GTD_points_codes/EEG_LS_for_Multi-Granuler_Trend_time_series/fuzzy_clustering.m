function [memberships]=fuzzy_clustering(X,cluster_number,people_col)
%This function makes the fuzzy c means clustering to create the membership of data_X.
% The "memberships" output shows the membership for each cluster.

%Here we first convert the density matrix to (n,1) and find its memberships.

q=istable(X);
if q==1
    X=table2array(X);
end

[sz1,sz2]=size(X);

XX=[];
for kl=1:sz2
  for mn=1:sz1
      if X(mn,kl)~=0
          XX=[XX;X(mn,kl)];
      end
  end
end

%%% Clustering according to quartiles and medians%%%%%%


[row_1,col_1]=size(XX);

nn=people_col;% people number in experiment
mmbrshps=[];
division=2*cluster_number-1; % if there is 3 label, there chould be 5 division on memembership func. and (for 4, need 7; for 5 , need 9... (2a-1))

for ll=1:row_1 % looking for all density number     
    for mmm=1:division % looking for all intervals
        if ((mmm*nn)/division)>XX(ll,1)&&(((mmm-1)*nn)/division)<XX(ll,1); % detecting the interval in membership function
            if rem(mmm,2)==1
                for gg=1:cluster_number
                    lbl=(mmm+1)/2;
                    if gg==lbl
                        mmbrshps(gg,ll)=1;                
                    else
                        mmbrshps(gg,ll)=0;
                    end
                end            
            else
                for hh=1:cluster_number
                  frst=(mmm/2);
                  scnd=(mmm/2)+1;
                  if hh==frst
                      mmbrshps(hh,ll)=mmm-((XX(ll,1)*division)/nn); %calculating membership degree for (mm-1). label
                  elseif hh==scnd
                      mmbrshps(hh,ll)=((XX(ll,1)*division)/nn)-mmm+1; %calculating membership degree for (mm+1). label
                  else
                      mmbrshps(hh,ll)=0;
                  end                  
                end
            end
            break;
        end
    end
end

% % % % % 
% % % % % % [centers,U] = fcm(XX,cluster_number);
% % % % % % 
% % % % % % % This part will sort the memberships from small to big;
% % % % % % buffer=sortrows([centers,U]);
% % % % % % mmbrshps=buffer(:,2:end);

%Then we convert the found membership matrix back to its original size (to X). Here, a cluster_number sized matrix is formed. The first dimensions start from the lightest membership and go to the largest membership.

% For example, the matrix (:,1,:) looks at the membership of the "big" tag, etc.

vall=0;
memberships=NaN(sz1,cluster_number,sz2);

for kl=1:sz2 %299
  for mn=1:sz1 %7
      if X(mn,kl)~=0
          vall=vall+1;
          for po=1:cluster_number
            memberships(mn,po,kl)=mmbrshps(po,vall);        
          end
      end
  end
end

end