function [ y ] = quant_at_least_half( x )
%UNT�TLED3 Summary of this function goes here
%   Detailed explanation goes here
% THIS CALCULATED ACCORDING TO PHD THES?S. HAKAN 
if x<=0.5
    y=2*x;
else
    y=1;
end
end