function membership = get_emotion_membership2(theta)
    % theta: Girilen a�? (derece, 0-360 aras?)
    % membership: 12x1 vekt�r, her etiketin �yelik derecesi

    % B�lge s?n?rlar?
    regions = [0 90 180 270 360];
    
    % �yelik derecelerini saklayacak vekt�r
    membership = zeros(16, 1);
    
    % Theta�y? 0-360 aral???na normalize et
    theta = mod(theta, 360);
    
    % Hangi b�lgeye d�?t�?�n� bul
    for r = 1:4
        if theta >= regions(r) && theta < regions(r+1)
            % B�lgenin ba?lang?� a�?s?
            start_angle = regions(r);
            
            % Etiket indeksleri (1-based): 4*(r-1)+1 ile 4*r
            idx = 4*(r-1) + 1;
            
            % Etiket 1: Yar?m ��gensel (maksimumdan azalan)
            a1 = start_angle;
            c1 = start_angle + 30;
            if theta >= a1 && theta <= c1
                membership(idx) = 1 - (theta - a1) / 30;
            end
            
            % Etiket 2: Tam ��gensel (0�-60� gibi)
            a2 = start_angle;
            b2 = start_angle + 30;
            c2 = start_angle + 60;
            if theta >= a2 && theta < b2
                membership(idx+1) = (theta - a2) / 30;
            elseif theta >= b2 && theta <= c2
                membership(idx+1) = 1 - (theta - b2) / 30;
            end
            
            % Etiket 3: Tam ��gensel (30�-90� gibi)
            a3 = start_angle + 30;
            b3 = start_angle + 60;
            c3 = start_angle + 90;
            if theta >= a3 && theta < b3
                membership(idx+2) = (theta - a3) / 30;
            elseif theta >= b3 && theta <= c3
                membership(idx+2) = 1 - (theta - b3) / 30;
            end
            
            % Etiket 4: Yar?m ��gensel (artan)
            a4 = start_angle + 60;
            b4 = start_angle + 90;
            if theta >= a4 && theta <= b4
                membership(idx+3) = (theta - a4) / 30;
            end
            break;
        end
    end
    
    % Negatif de?erleri s?f?r yap (her ihtimale kar??)
    membership(membership < 0) = 0;
end