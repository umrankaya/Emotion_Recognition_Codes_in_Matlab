function [group1, group2, group3, accuracy] = EmotionGroups(data, PopulationSize)
    % Veri ve GA ayarlar?
    numEmotions = size(data, 2); % Duygu say?s?
    numCategories = 3; % Kategori say?s?
    trueLabels = [1; 2; 3; 3; 2; 1; 3; 2; 1; 1; 2; 3; 2; 1; 3];

    % Genetik algoritma ayarlar?
    options = optimoptions('ga', ...
        'PopulationSize', PopulationSize, ...
        'MaxGenerations', 200, ...
        'Display', 'iter');

    % Genetik algoritmay? �al??t?r
    [bestAssignment, ~] = ga(@(x)fitnessFunc(x, data, trueLabels, numEmotions, numCategories), ...
        numEmotions * numCategories, [], [], [], [], ...
        zeros(1, numEmotions * numCategories), ones(1, numEmotions * numCategories), ...
        @(x)constraintFunc(x, numEmotions, numCategories), ...
        options);

    % Sonu�lar?
    assignmentMatrix = reshape(bestAssignment, numEmotions, numCategories);
    [~, emotionGroups] = max(assignmentMatrix, [], 2);

    % 3 grup etiketi
    group1 = find(emotionGroups == 1);
    group1=transp(group1);
    group2 = find(emotionGroups == 2);
    group2=transp(group2);
    group3 = find(emotionGroups == 3);
    group3=transp(group3);

    % Do?ruluk oran?
    predictedLabels = predictLabels(data, emotionGroups);
    accuracy = mean(predictedLabels == trueLabels) * 100;
end

% Fitness Fonksiyonu
function error = fitnessFunc(assignment, data, trueLabels, numEmotions, numCategories)
    assignmentMatrix = reshape(assignment, numEmotions, numCategories);
    [~, emotionGroups] = max(assignmentMatrix, [], 2);
    predictedLabels = predictLabels(data, emotionGroups);
    error = 1 - mean(predictedLabels == trueLabels);
end

% K?s?t Fonksiyonu
function [c, ceq] = constraintFunc(assignment, numEmotions, numCategories)
    assignmentMatrix = reshape(assignment, numEmotions, numCategories);
    [~, emotionGroups] = max(assignmentMatrix, [], 2);
    categoryCounts = histcounts(emotionGroups, 1:numCategories + 1);
    c = [categoryCounts - 6, 1 - categoryCounts];
    ceq = [];
end

% Etiket Tahmini
function predictedLabels = predictLabels(data, emotionGroups)
    numVideos = size(data, 1);
    numCategories = max(emotionGroups);
    scores = zeros(numVideos, numCategories);
    for i = 1:numCategories
        scores(:, i) = sum(data(:, emotionGroups == i), 2);
    end
    [~, predictedLabels] = max(scores, [], 2);
end