function [membership_degree]=mem_degree_for_all_emotion(arousal,valence,labels)
% Each EEG signal's membership degree to emotional labels will be
% calculated as using label_fuzzy_labels function
membership_degree=[]; % an empty matris to fill with membersip degree for each EEG signal (time_points_300*emotions_16*people_17)(300*16*17)
all_angles=[]; % All angles are kept in this matris

[num_of_points,num_of_people]=size(arousal);

for p=1:num_of_people
    for t=1:num_of_points

        [fs,label_values]=label_fuzzy_set(arousal(t,p),valence(t,p),labels); % calculating with iteration
        all_angles=[all_angles,fs]; % Each angle added to matris
        membership_degree(t,:,p)=label_values; % collecting in this matris

    end
end
end