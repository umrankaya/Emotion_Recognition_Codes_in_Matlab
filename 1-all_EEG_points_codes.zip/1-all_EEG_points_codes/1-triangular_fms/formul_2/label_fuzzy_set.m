function [fs,label_values]=label_fuzzy_set(ar,val,labels)

% In this functin, we calculate the membership degree of any arousal/valence values according to labels
%First we defined whole labels and then added local labels for each quadrant.

% labels={'happy','elated','excited','alert','tense','nervous','stressed','upset','sad','depressed','lethargic','fatigued','calm','relaxed','serene','contented'};

% we wanna create a matris to write memebership degree for each labels
sz=size(labels); 
label_values=zeros(1,sz(1,2)); % for each angle, membership degree will be written to this matris

fi=0; % fi shows the angle 

% For arousal and valuence values, quadrant is detected and angle is calculated
if ar>0 && val>0
    fi=atan(ar/val);
elseif ar>0 && val<0
    fi=pi-abs(atan(ar/val));
elseif ar<0 && val<0
    fi=pi+atan(ar/val);        
else
    fi=2*pi-abs(atan(ar/val));   
end

fs=fi;

% 
for j=1:4 % detecting membership degree for each quadrant
    for i=1:3 % for esch quadrant, there are 4 label, but 3 same "cross" pattern. For same pattern, looking for each label couple. and looking all as sliding window
        first=((i-1)*(pi/6)+(j-1)*(pi/2)); % same patterns interval is pi/6. This variable detect the first point of interval on quadrant
        last=(i*(pi/6)+(j-1)*(pi/2)); % this detects last point on interval, too.
        
        if fi>first && fi<=last % detecting interval
            label_values(1,(i+4*(j-1)))=(last-fi)/(last-first); % for each interval, this calculate the membership degree of FIRST label of couple, and assign on label_values matris
            label_values(1,(i+4*(j-1))+1)=(fi-first)/(last-first); % for each interval, this calculate the membership degree of SECOND label of couple, and assign on label_values matris
        end
    end 
end















end