clc;
clear all;

%%%%%%%%%%%%%%%%%--------------------------------------------------%%%%%%%%%%%%%%%%%%%%%%%%%
                            %%% Getting DATA from source file %%%
%%%%%%%%%%%%%%%%%--------------------------------------------------%%%%%%%%%%%%%%%%%%%%%%%%%
clc;
clear all;
main_folder = 'D:\Users\umran.kaya\Desktop\SEED_EEG\Preprocessed_EEG\Preprocessed_EEG\1-Veriler\last_version'; % Ana klas�r yolu
subfolders = dir(main_folder);
subfolders = subfolders([subfolders.isdir] & ~ismember({subfolders.name}, {'.', '..'})); % Ge�erli alt klas�rleri se�

file_names = {'dataa_audio', 'dataa_video', 'dataa_web'}; % Sabit dosya isimleri
combined_video_based_all=[];
combined_subject_based_all=[];

for i = 1:length(subfolders)
    subfolder_path = fullfile(main_folder, subfolders(i).name); % Alt klas�r�n tam yolu
    mat_files = dir(fullfile(subfolder_path, '*.mat')); % .mat dosyalar?n? listele
    
    for j = 1:min(length(mat_files), 3) % ?lk 3 dosya i�in i?lem yap
        mat_file_path = fullfile(subfolder_path, mat_files(j).name); % .mat dosyas?n?n tam yolu
        var_name = file_names{j}; % Sabit isimleri kullan
        eval([var_name ' = load(mat_file_path);']); % .mat dosyas?n? y�kleyip de?i?kene ata
%         fprintf('Y�klendi: %s\%s\%s ve de?i?kene atand?: %s\n', main_folder, subfolders(i).name, mat_files(j).name, var_name);
    end

% [dataa_audio] = load("D:\Users\umran.kaya\Desktop\SEED_EEG\Preprocessed_EEG\Preprocessed_EEG\1-Veriler\1_trial_repro_cinsiyet\24_20130709_processed.mat");
% [dataa_video] = load("D:\Users\umran.kaya\Desktop\SEED_EEG\Preprocessed_EEG\Preprocessed_EEG\1-Veriler\2_trial_repro_cinsiyet\24_20131016_processed.mat");
% [dataa_web] = load("D:\Users\umran.kaya\Desktop\SEED_EEG\Preprocessed_EEG\Preprocessed_EEG\1-Veriler\3_trial_repro_cinsiyet\24_20131105_processed.mat");

% veri matrix hale d�n�?t�r�l�yor
dataa_audio=struct2cell(dataa_audio);
EEG_audio=cell2mat(dataa_audio(1,1));
dataa_video=struct2cell(dataa_video);
EEG_video=cell2mat(dataa_video(1,1));
dataa_web=struct2cell(dataa_web);
EEG_web=cell2mat(dataa_web(1,1));

% && Calculating Arousal and Valence values and Resulting with converting them with normalization method &&%
                                        %%% for AUDIO EEG DATA %%%%
[arousal_audio,valence_audio]=arousal_valence_calc(EEG_audio); % a function that calculating the arousal and valence values
arousal_audio=real(arousal_audio);
valence_audio=real(valence_audio);
% [arousal_audio_n,valence_audio_n]=norm_arousal_valence(arousal_audio,valence_audio); % a function that normalize the Arousal and Valence between [-1,1] interval
                                        %%% for VIDEO EEG DATA %%%%
[arousal_video,valence_video]=arousal_valence_calc(EEG_video); % a function that calculating the arousal and valence values
arousal_video=real(arousal_video);
valence_video=real(valence_video);
% [arousal_video_n,valence_video_n]=norm_arousal_valence(arousal_video,valence_video); % a function that normalize the Arousal and Valence between [-1,1] interval
                                         %%% for WEB EEG DATA %%%%
[arousal_web,valence_web]=arousal_valence_calc(EEG_web); % a function that calculating the arousal and valence values
arousal_web=real(arousal_web);
valence_web=real(valence_web);
% [arousal_web_n,valence_web_n]=norm_arousal_valence(arousal_web,valence_web); % a function that normalize the Arousal and Valence between [-1,1] interval

          % && Calculating AW Index and Resulting with converting them with normalization method &&%
 %%% for AUDIO EEG DATA %%%%
 [AW_audio]=AW_calc(EEG_audio);

 %%% for VIDEO EEG DATA %%%%
 [AW_video]=AW_calc(EEG_video);

 %%% for WEB EEG DATA %%%%
 [AW_web]=AW_calc(EEG_web);

 %& Until this point, we got the data and make the preprocess (filling missing data,calc arousal/valence, AW,)
 %& Now, we will create the fuzzy sets. Before creating the protoforms, we should create the labels fuzzy sets to get membership degrees while
 %calculating the truth values.
 
 %%%%%%%%%%%%%%%%%--------------------------------------------------%%%%%%%%%%%%%%%%%%%%%%%%%
                            %%% Creating FUZZY SETS for ALL LABELS %%%
%%%%%%%%%%%%%%%%%--------------------------------------------------%%%%%%%%%%%%%%%%%%%%%%%%%

                     %%&---------------- EMOTIONS FUZZY SETS---------------- %&
%& 1) ALL EMOTIONS LABELS:

labels_all_emotion={'happy','elated','excited','alert','tense','nervous','stressed','upset','sad','depressed','lethargic','fatigued','calm','relaxed','serene','contented'}; % labels used in emotion detection. This data used in label_fuzzy_set

% These "all_emotions_mmbrship_dgre_audio/video/web" matrix size is 300*16*17. 
% It means that for all 17 people, 300 time points' value is converted to 16 emotions' membership degree.

[all_emotions_mmbrship_dgre_audio]=mem_degree_for_all_emotion(arousal_audio,valence_audio,labels_all_emotion);
[all_emotions_mmbrship_dgre_video]=mem_degree_for_all_emotion(arousal_video,valence_video,labels_all_emotion);
[all_emotions_mmbrship_dgre_web]=mem_degree_for_all_emotion(arousal_web,valence_web,labels_all_emotion);

% T�m emotionlar i�in �yelik derecelerinin toplam? hesaplan?yor
video_based_all_emotion_1_trial=[];
video_based_all_emotion_2_trial=[];
video_based_all_emotion_3_trial=[];
subject_based_all_emotion_1_trial=[];
subject_based_all_emotion_2_trial=[];
subject_based_all_emotion_3_trial=[];

[raww,coloumn,depth]=size(all_emotions_mmbrship_dgre_audio);

for hh=1:16 % 16 adet duygu oldu?u i�in
    % video bazl? �yelik dreceleri toplan?yor
    video_based_all_emotion_1_trial(1,hh) = (sum(sum(all_emotions_mmbrship_dgre_audio(:,hh,:)))/(raww*depth));
    video_based_all_emotion_2_trial(1,hh) = (sum(sum(all_emotions_mmbrship_dgre_video(:,hh,:)))/(raww*depth));
    video_based_all_emotion_3_trial(1,hh) = (sum(sum(all_emotions_mmbrship_dgre_web(:,hh,:)))/(raww*depth));
    
    for pp=1:15 % 15 ki?i oldu?u i�in
        subject_based_all_emotion_1_trial(pp,hh) = (sum(all_emotions_mmbrship_dgre_audio(:,hh,pp))/(raww)); % sat?rda ki?iler, s�tunda duygu �yelikleri
        subject_based_all_emotion_2_trial(pp,hh) = (sum(all_emotions_mmbrship_dgre_video(:,hh,pp))/(raww)); % sat?rda ki?iler, s�tunda duygu �yelikleri
        subject_based_all_emotion_3_trial(pp,hh) = (sum(all_emotions_mmbrship_dgre_web(:,hh,pp))/(raww)); % sat?rda ki?iler, s�tunda duygu �yelikleri
    end    
end

%& 2) BASIC EMOTIONS LABELS:

labels_basic_emotion={'thrilling','hard-pressed','pessimist','mitigated'}; % labels used in emotion detection. This data used in basic_labels_fuzzy_set

% These "basic_emotions_mmbrship_dgre_audio/video/web" matrix size is 300*4*17. 
% It means that for all 17 people, 300 time points' value is converted to 4 emotions' membership degree.

[basic_emotions_mmbrship_dgre_audio]=mem_degree_for_basic_emotion(arousal_audio,valence_audio,labels_basic_emotion);
[basic_emotions_mmbrship_dgre_video]=mem_degree_for_basic_emotion(arousal_video,valence_video,labels_basic_emotion);
[basic_emotions_mmbrship_dgre_web]=mem_degree_for_basic_emotion(arousal_web,valence_web,labels_basic_emotion);

% T�m emotionlar i�in �yelik derecelerinin toplam? hesaplan?yor
video_based_basic_emotion_1_trial=[];
video_based_basic_emotion_2_trial=[];
video_based_basic_emotion_3_trial=[];
subject_based_basic_emotion_1_trial=[];
subject_based_basic_emotion_2_trial=[];
subject_based_basic_emotion_3_trial=[];
for hh=1:4  % 4 adet duygu oldu?u i�in
    % video bazl? �yelik dreceleri toplan?yor
    video_based_basic_emotion_1_trial(1,hh) = (sum(sum(basic_emotions_mmbrship_dgre_audio(:,hh,:)))/(raww*depth));
    video_based_basic_emotion_2_trial(1,hh) = (sum(sum(basic_emotions_mmbrship_dgre_video(:,hh,:)))/(raww*depth));
    video_based_basic_emotion_3_trial(1,hh) = (sum(sum(basic_emotions_mmbrship_dgre_web(:,hh,:)))/(raww*depth));
    
    for pp=1:15 % 15 ki?i oldu?u i�in
        subject_based_basic_emotion_1_trial(pp,hh) = (sum(basic_emotions_mmbrship_dgre_audio(:,hh,pp))/(raww)); % sat?rda ki?iler, s�tunda duygu �yelikleri
        subject_based_basic_emotion_2_trial(pp,hh) = (sum(basic_emotions_mmbrship_dgre_video(:,hh,pp))/(raww)); % sat?rda ki?iler, s�tunda duygu �yelikleri
        subject_based_basic_emotion_3_trial(pp,hh) = (sum(basic_emotions_mmbrship_dgre_web(:,hh,pp))/(raww)); % sat?rda ki?iler, s�tunda duygu �yelikleri
    end    
end

%& 3) AW INDEX LABELS:

labels_AW_emotion={'negative','neutral','positive'}; % labels used in emotion detection. This data used in AW_labels_fuzzy_set

% These "AW_index_mmbrship_dgre_audio/video/web" matrix size is 300*3*17. 
% It means that for all 17 people, 300 time points' value is converted to 3 emotions' membership degree.

[AW_index_mmbrship_dgre_audio]=mem_degree_for_AW_index(AW_audio,labels_AW_emotion);
[AW_index_mmbrship_dgre_video]=mem_degree_for_AW_index(AW_video,labels_AW_emotion);
[AW_index_mmbrship_dgre_web]=mem_degree_for_AW_index(AW_web,labels_AW_emotion);

% T�m emotionlar i�in �yelik derecelerinin toplam? hesaplan?yor
video_based_AW_emotion_1_trial=[];
video_based_AW_emotion_2_trial=[];
video_based_AW_emotion_3_trial=[];
subject_based_AW_emotion_1_trial=[];
subject_based_AW_emotion_2_trial=[];
subject_based_AW_emotion_3_trial=[];
for hh=1:3  % 3 adet duygu oldu?u i�in
    % video bazl? �yelik dreceleri toplan?yor
    video_based_AW_emotion_1_trial(1,hh) = (sum(sum(AW_index_mmbrship_dgre_audio(:,hh,:)))/(raww*depth));
    video_based_AW_emotion_2_trial(1,hh) = (sum(sum(AW_index_mmbrship_dgre_video(:,hh,:)))/(raww*depth));
    video_based_AW_emotion_3_trial(1,hh) = (sum(sum(AW_index_mmbrship_dgre_web(:,hh,:)))/(raww*depth));
    
    for pp=1:15 % 15 ki?i oldu?u i�in
        subject_based_AW_emotion_1_trial(pp,hh) = (sum(AW_index_mmbrship_dgre_audio(:,hh,pp))/(raww)); % sat?rda ki?iler, s�tunda duygu �yelikleri
        subject_based_AW_emotion_2_trial(pp,hh) = (sum(AW_index_mmbrship_dgre_video(:,hh,pp))/(raww)); % sat?rda ki?iler, s�tunda duygu �yelikleri
        subject_based_AW_emotion_3_trial(pp,hh) = (sum(AW_index_mmbrship_dgre_web(:,hh,pp))/(raww)); % sat?rda ki?iler, s�tunda duygu �yelikleri
    end    
end
video_based_all=[video_based_AW_emotion_1_trial,video_based_AW_emotion_2_trial,video_based_AW_emotion_3_trial,0,video_based_basic_emotion_1_trial,video_based_basic_emotion_2_trial,video_based_basic_emotion_3_trial,0,video_based_all_emotion_1_trial,video_based_all_emotion_2_trial,video_based_all_emotion_3_trial];
p1=[subject_based_AW_emotion_1_trial;subject_based_AW_emotion_2_trial;subject_based_AW_emotion_3_trial];
p2=[subject_based_basic_emotion_1_trial;subject_based_basic_emotion_2_trial;subject_based_basic_emotion_3_trial];
p3=[subject_based_all_emotion_1_trial;subject_based_all_emotion_2_trial;subject_based_all_emotion_3_trial];
subject_based_all=[[p1,zeros(45,1),p2,zeros(45,1),p3]];

    combined_video_based_all(i,:)=video_based_all;
    combined_subject_based_all(:,:,i)=subject_based_all;
end

% Ki?i bazl? verileri d�zenlemek i�in...
[raww,coloumn,depth]=size(combined_subject_based_all);
subject_based_redesign=[];
for tt=1:depth % videolara g�re..
    for mm=1:15 % ki?ilere g�re..
        subject_based_redesign((3*tt-2),:,mm)=combined_subject_based_all(mm,:,tt); % ki?inin 1. trial?
        subject_based_redesign((3*tt-1),:,mm)=combined_subject_based_all((mm+15),:,tt); % ki?inin 2. trial?
        subject_based_redesign((3*tt),:,mm)=combined_subject_based_all((mm+30),:,tt); % ki?inin 3. trial?
    end
end

% assignment of points
PopulationSize=50000;
mmbrships=combined_video_based_all(:,24:39);
[columnsPoz, columnsNotr, columnsNeg, Overall_Accuracy] = EmotionGroups(mmbrships, PopulationSize);

%%%%%%%%%%%%%% Accuracy calculation for overall video  %%%%%%%%%%%%%%

% Ger�ek etiketler 1=pozitive, 2=neurtal, 3=negative
trueLabels = [1, 2, 3, 3, 2, 1, 3, 2, 1, 1, 2, 3, 2, 1, 3];
actualLabels=[];
pnn=[]; % pozitif, n�tr ve negatif de?erleri tutacak

for la=1:15 % her video i�in pozitif, n�tr ve negatif de?erler hesaplanacak
    pnn(1,1)=sum(mmbrships(la, columnsPoz));
    pnn(1,2)=sum(mmbrships(la, columnsNotr));
    pnn(1,3)=sum(mmbrships(la, columnsNeg));
    
    [max_val, linear_idx] = max(pnn(:)); % hangi etiketse indexini belirler
    actualLabels(1,la)=linear_idx;   
end

% Dogru tahminlerin oran? (dogruluk)
dogruluk = sum(trueLabels == actualLabels) / numel(trueLabels);
% Sonucu y�zde olarak g�sterme
disp(['Accuracy: ', num2str(dogruluk * 100), '%']);



%%%%%%%%%%%%%% Accuracy calculation for subject based  %%%%%%%%%%%%%%
% Ger�ek etiketler 1=pozitive, 2=neurtal, 3=negative
% trueLabels = [1, 2, 3, 3, 2, 1, 3, 2, 1, 1, 2, 3, 2, 1, 3];

mmbrships_subject=subject_based_redesign(1:15,10:25,:);
pnn_s=[]; % pozitif, n�tr ve negatif de?erleri tutacak
accuracy_subject_based=zeros(1,15);

for la_i=1:15 % her ki?i i�in pozitif, n�tr ve negatif degerler hesaplanacak
    actualLabelsSubject=zeros(1,15);
    for la_il=1:15 % bireysel bazda t�m videolara bakacak
        
        pnn_s(1,1)=sum(mmbrships_subject(la_il, columnsPoz,la_i));
        pnn_s(1,2)=sum(mmbrships_subject(la_il, columnsNotr,la_i));
        pnn_s(1,3)=sum(mmbrships_subject(la_il, columnsNeg,la_i));

        [max_val, linear_idx] = max(pnn_s(:)); % hangi etiketse indexini belirler
        actualLabelsSubject(1,la_il)=linear_idx;   
    end
    % Dogru tahminlerin oran? (dogruluk)
    dogruluk_subject = sum(trueLabels == actualLabelsSubject) / numel(trueLabels);
    accuracy_subject_based(1,la_i)=dogruluk_subject;
end


% Dosyaya yazma
% Sonu�lar
% Dosya konumu ve ismi
outputFolder = 'D:\Users\umran.kaya\Desktop\SEED_EEG\Preprocessed_EEG\Preprocessed_EEG\3-Sonuclar\1_triangular\formul_3';
fileName = '1_triangular_formul_3.txt';

% Dosyay? a� ve yaz
fileID = fopen(fullfile(outputFolder, fileName), 'w');

% Sonu�lar? alt alta ba?l?klarla yaz
fprintf(fileID, 'Overall Accuracy: %.2f\n', Overall_Accuracy);
fprintf(fileID, 'Dogruluk: %.2f\n', dogruluk);
fprintf(fileID, 'Accuracy Based on Subject:\n');
fprintf(fileID, '%.2f ', accuracy_subject_based');

fclose(fileID);

disp('Sonu�lar belirtilen klas�re tek bir dosyada yaz?ld?!');






