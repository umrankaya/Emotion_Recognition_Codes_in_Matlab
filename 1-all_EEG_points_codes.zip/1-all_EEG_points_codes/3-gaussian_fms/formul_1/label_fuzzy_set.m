function [fs,label_values]=label_fuzzy_set(ar,val,labels)

% In this functin, we calculate the membership degree of any arousal/valence values according to labels
%First we defined whole labels and then added local labels for each quadrant.

% labels={'happy','elated','excited','alert','tense','nervous','stressed','upset','sad','depressed','lethargic','fatigued','calm','relaxed','serene','contented'};

% we wanna create a matris to write memebership degree for each labels
sz=size(labels); 
label_values=zeros(1,sz(1,2)); % for each angle, membership degree will be written to this matris

fi=0; % fi shows the angle 

% For arousal and valuence values, quadrant is detected and angle is calculated
if ar>0 && val>0
    fi=atan(ar/val)*(180/pi);
elseif ar>0 && val<0
    fi=(pi-abs(atan(ar/val)))*(180/pi);
elseif ar<0 && val<0
    fi=(pi+atan(ar/val))*(180/pi);        
else
    fi=(2*pi-abs(atan(ar/val)))*(180/pi);   
end

fs=fi;

label_values=computeGaussianMemberships(fs);

end